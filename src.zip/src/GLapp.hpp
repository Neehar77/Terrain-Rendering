// collected state for access in callbacks
// 
#pragma once

class GLapp {
public:
    struct GLFWwindow *win;      // graphics window from GLFW system
    class Scene *scene;         // viewing data
    class Input *input;         // user interface data
    class character *Character; //character geometry 
    class Terrain *terrain;     // terrain geometry
    bool redraw;				// true if screen needs to be redrawn

    // uniform buffer indices
    enum { SCENE_UNIFORMS, NUM_UNIFORMS };

    // initialize and destroy app data
    GLapp();
    ~GLapp();
};

// single global application context
extern GLapp *gApp;

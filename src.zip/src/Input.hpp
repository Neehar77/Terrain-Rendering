// handle changes due to mouse motion, or keys
#pragma once
#include "Vec.inl"

struct GLFWwindow;

class Input {
// private data
private:
    int button;                 // which mouse button was pressed?
    double oldX, oldY;          // location of mouse at last event

    double updateTime;          // time (in seconds) of last update
    float walkSpeed, runSpeed;  // base rates for running or walking
    float walk, strafe, speed;  // keyboard motion direction and speed
    int i = 0;
    double t;
    Vec3f pos1, pos2, pos3, pos4;        //four segments                 
public:                                     // public methods
    // initialize
    Input();

    // handle mouse press / release
    void mousePress(GLFWwindow *win, int button, int action);

    // handle mouse motion
    void mouseMove(GLFWwindow *win, double x, double y);

    // handle key press or release
    void keyPress(GLFWwindow *win, int keycode, int action);

    // update view (if necessary) based on key input
    void keyUpdate();

    //position catmull-rom spline 
    void catmullRomSpline();
public:
    //Get catmull-Rom spline
    Vec3f getCatmullRomSpline(float t, Vec3f p0, Vec3f p1, Vec3f p2, Vec3f p3);
};

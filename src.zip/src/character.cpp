#include "Render.hpp"
#include <GL\glew.h>
#include <GLFW/glfw3.h>
#include "ImagePPM.hpp"
#include <fstream>
#include <string>
#include "GLapp.hpp"
#include <sstream>
#include "Vec.inl"
#include <iostream>
using namespace std;


void character::init(const char* vertexshader, const char* fragmentshader, const char* texture, const char* normals)
{
	// buffer objects to be used later
	glGenTextures(NUM_TEXTURES, textureIDs);
	glGenBuffers(NUM_BUFFERS, bufferIDs);
	glGenVertexArrays(1, &varrayID);

	// load color image into a named texture
	ImagePPM(texture).loadTexture(textureIDs[COLOR_TEXTURE]);
	//load another texture normal mapping
	ImagePPM(normals).loadTexture(textureIDs[NUM_NORMALS]);
	//ImagePPM(texture).loadTexture(textureIDs[NUM_NORMALS]);

	// load vertex and index array to GPU
	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[POSITION_BUFFER]);
	glBufferData(GL_ARRAY_BUFFER, vert.size() * sizeof(vert[0]), &vert[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[NORMAL_BUFFER]);
	glBufferData(GL_ARRAY_BUFFER, norm.size() * sizeof(norm[0]), &norm[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[UV_BUFFER]);
	glBufferData(GL_ARRAY_BUFFER, uv.size() * sizeof(uv[0]), &uv[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferIDs[INDEX_BUFFER]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(indices[0]), &indices[0], GL_STATIC_DRAW);

	// initial shader load
	shaderParts[0].id = glCreateShader(GL_VERTEX_SHADER);
	shaderParts[0].file = vertexshader;
	shaderParts[1].id = glCreateShader(GL_FRAGMENT_SHADER);
	shaderParts[1].file = fragmentshader;
	shaderID = glCreateProgram();
	updateShaders();
}
void character::updateShaders()
{
	loadShaders(shaderID, sizeof(shaderParts) / sizeof(*shaderParts),
		shaderParts);
	glUseProgram(shaderID);

	// (re)connect view and projection matrices
	glUniformBlockBinding(shaderID,
		glGetUniformBlockIndex(shaderID, "SceneData"),
		GLapp::SCENE_UNIFORMS);

	//map shader name for texture to GL_TEXTURE0 used in draw
	glUniform1i(glGetUniformLocation(shaderID, "colorTexture"), 0);
	// normal shader name for texture to GL_TEXTURE1 used in draw
	glUniform1i(glGetUniformLocation(shaderID, "normalTexture"), 1);
	//re-connect attribute arrays
	glBindVertexArray(varrayID);

	GLint positionAttrib = glGetAttribLocation(shaderID, "vPosition");
	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[POSITION_BUFFER]);
	glVertexAttribPointer(positionAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(positionAttrib);

	GLint normalAttrib = glGetAttribLocation(shaderID, "vNormal");
	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[NORMAL_BUFFER]);
	glVertexAttribPointer(normalAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(normalAttrib);

	GLint uvAttrib = glGetAttribLocation(shaderID, "vUV");
	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[UV_BUFFER]);
	glVertexAttribPointer(uvAttrib, 2, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(uvAttrib);

}
character::character(const char* texturePPM, const char* characterobj, const char* normalPPM)
{
	// build vertex, normal and texture coordinate arrays
	//path = "C:/Users/baap1/Documents/Studies_Sem2/Project1_Graphics/neehart1/GLapp/data/olano.obj";
	std::ifstream file("C:/Users/baap1/Documents/Studies_Sem2/Project1_Graphics/neehart1/GLapp/data/olano.obj");
	//unsigned int count = 0;
	//file.open(path);
	//FILE* file = fopen(path, "rt");
	if (file.is_open())
	{
		while (getline(file, line))
		{
			istringstream obj(line);
			if (line.find("vt") == 0)
			{
				float uvx, uvy;
				obj.ignore(2, 'vt');
				obj >> uvx >> uvy;
				temp_uvs.push_back(vec2<float>(uvx, 1-uvy));
				continue;
			}
			else if (line.find("vn") == 0)
			{
				float vnx, vny, vnz;
				obj.ignore(2, 'vn');
				obj >> vnx >> vny >> vnz;
				temp_normals.push_back(vec3<float>(vnx, vny, vnz));
				continue;
			}
			else if (line.find("v") == 0)
			{
				float vx, vy, vz;
				obj.ignore(1, 'v');
				obj >> vx >> vy >> vz;
				temp_vertices.push_back(vec3<float>(vx, vy, vz));
				continue;
			}
			else if (line.find("f") == 0)
			{
				string vertex1, vertex2, vertex3;
				unsigned int vertex[9];
				obj.ignore(1, 'f');
				for (int i = 0; i < 9; i++)
				{
					obj >> vertex[i];
					obj.ignore(1, '/');
				}
				vertex1 = to_string(vertex[0]) + to_string(vertex[1]) + to_string(vertex[2]);
				vertex2 = to_string(vertex[3]) + to_string(vertex[4]) + to_string(vertex[5]);
				vertex3 = to_string(vertex[6]) + to_string(vertex[7]) + to_string(vertex[8]);
				//mapping.insert(pair<string, int>(to_string(vertex1[0]) + to_string(vertex1[1]) + to_string(vertex1[2]), count));
				//mapping.insert(pair<string, int>(to_string(vertex1[0]) + to_string(vertex1[1]) + to_string(vertex1[2]), count + 1));
				//mapping.insert(pair<string, int>(to_string(vertex1[0]) + to_string(vertex1[1]) + to_string(vertex1[2]), count + 2));
				if (mapping.find(vertex1) == mapping.end())
				{
					mapping[vertex1] = count;
					indices.push_back(count);
					vert.push_back(temp_vertices[vertex[0] - 1]);
					uv.push_back(temp_uvs[vertex[1] - 1]);
					norm.push_back(temp_normals[vertex[2] - 1]);
					count++;
				}
				else
				{
					indices.push_back(mapping[vertex1]);
				}
				if (mapping.find(vertex2) == mapping.end())
				{
					mapping[vertex2] = count;
					indices.push_back(count);
					vert.push_back(temp_vertices[vertex[3] - 1]);
					uv.push_back(temp_uvs[vertex[4] - 1]);
					norm.push_back(temp_normals[vertex[5] - 1]);
					count++;
				}
				else
				{
					indices.push_back(mapping[vertex2]);
				}
				if (mapping.find(vertex3) == mapping.end())
				{
					mapping[vertex3] = count;
					indices.push_back(count);
					vert.push_back(temp_vertices[vertex[6] - 1]);
					uv.push_back(temp_uvs[vertex[7] - 1]);
					norm.push_back(temp_normals[vertex[8] - 1]);
					count++;
				}
				else
				{
					indices.push_back(mapping[vertex3]);
				}
			}
		}
	}
	init("terrain.vert", "terrain.frag", texturePPM, normalPPM);
}



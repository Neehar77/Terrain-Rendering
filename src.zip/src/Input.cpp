// set up and maintain view as window sizes change

#include "Input.hpp"
#include "GLapp.hpp"
#include "Scene.hpp"
#include "Render.hpp"
#include "Vec.inl"

// using core modern OpenGL
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <math.h>

#ifndef F_PI
#define F_PI 3.1415926f
#endif

// initialize
Input::Input()
    : button(-1), oldX(0), oldY(0),
      walkSpeed(20), runSpeed(80),
      walk(0), strafe(0), speed(walkSpeed)
{}

//
// called when a mouse button is pressed. 
// Remember where we were, and what mouse button it was.
//
void Input::mousePress(GLFWwindow *win, int b, int action)
{
    if (action == GLFW_PRESS) {
        // hide cursor, record button
        glfwSetInputMode(win, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
        button = b;
        glfwGetCursorPos(win, &oldX, &oldY);
    }
    else {
        // display cursor, update button state
        glfwSetInputMode(win, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
        button = -1;       // no button
    }
}

//
// called when the mouse moves
// use difference between oldX,oldY and x,y to define a rotation
//
void Input::mouseMove(GLFWwindow *win, double x, double y)
{
    if (button == GLFW_MOUSE_BUTTON_LEFT) {
        // rotation angle, scaled so across the window = one rotation
        gApp->scene->pan += float(F_PI * float(x - oldX) / gApp->scene->width);
        gApp->scene->tilt += float(0.5f*F_PI * float(y - oldY) / gApp->scene->height);
        gApp->Character->vert;
        gApp->scene->Move(gApp->scene->position);
        //gApp->scene->objectView(gApp->scene->position);

        // tell GLFW that something has changed and we must redraw
        gApp->redraw = true;
        oldX = x;
        oldY = y;
    }
}

//
// called when any key is pressed
//
void Input::keyPress(GLFWwindow *win, int key, int action)
{
    if (action == GLFW_PRESS) {
        switch (key) {
        case 'A':                   // strafe left
            //gApp->Character->vert;
            strafe = -1;
            break;

        case 'D':                   // strafe right
            //gApp->Character->vert.begin();
            strafe = 1;
            break;

        case 'W':                   // walk forward
            //gApp->Character->vert.begin();
            walk = 1;
            break;

        case 'S':                   // walk backwards
            //gApp->Character->vert.begin();
            walk = -1;
            break;

        case GLFW_KEY_LEFT_SHIFT:          // shift run modifier
        case GLFW_KEY_RIGHT_SHIFT:
            speed = runSpeed;
            break;
        case 'N':          //Normal Mapping On or Off
            gApp->scene->sdata.normal_map.a = 1 - gApp->scene->sdata.normal_map.a;
            break;
        case 'G':          //Surface Gradient On or Off
            gApp->scene->sdata.surface_gradient.a = 1 - gApp->scene->sdata.surface_gradient.a;
            break;
        case 'R':                   // reload shaders
            gApp->terrain->updateShaders();
            gApp->Character->updateShaders();
            break;
        case 'P':
            catmullRomSpline();
            gApp->scene->playback(pos1);
            gApp->scene->playback(pos2);
            gApp->scene->playback(pos3);
            gApp->scene->playback(pos4);
            break;                  //Playback last 5 seconds 
        case 'F':                   // toggle fog on or off
            gApp->scene->sdata.fog.a = 1 - gApp->scene->sdata.fog.a;
            break;
        case GLFW_KEY_ESCAPE:                    // Escape: exit
            glfwSetWindowShouldClose(win, true);
            return;

        default:
            return;
        }

        // Any non-handled key returns before now, set to redraw
        updateTime = glfwGetTime();
        gApp->redraw = true;
    }

    if (action == GLFW_RELEASE) {
        switch (key) {
        case 'A': case 'D':         // stop left/right motion
            strafe = 0;
            return;

        case 'W': case 'S':         // stop forward/backward motion
            walk = 0;
            return;

        case GLFW_KEY_LEFT_SHIFT:                 // stop sprinting
        case GLFW_KEY_RIGHT_SHIFT:
            speed = walkSpeed;
            return;

        default:
            return;
        }
    }
}
//
// update view if necessary based on a/d keys
//
void Input::keyUpdate()
{
    if (walk != 0 || strafe != 0) {
        double now = glfwGetTime();
        float dt = float(now - updateTime);
        // update position
        float c = cos(gApp->scene->pan), s = sin(gApp->scene->pan);
        Vec3f newPosition = gApp->scene->position
            + vec3<float>(s,  c, 0) * (dt * speed * walk)
            + vec3<float>(c, -s, 0) * (dt * speed * strafe);
        if (i < 6)
        {
            if (i == 5)
            {
                i = i % 5;
            }
            else
            {
                gApp->scene->playBackPosition[i] = gApp->scene->position
                    + vec3<float>(s, c, 0) * (dt-i * speed * walk)
                    + vec3<float>(c, -s, 0) * (dt-i * speed * strafe);
                i = i + 1;
            }
        }
        gApp->scene->Move(newPosition);
        //gApp->scene->objectView(newPosition);
       
        // remember time for next update
        updateTime = now;

        // changing, so will need to start another draw
        gApp->redraw = true;
    }
}

void Input::catmullRomSpline()
{
       Vec3f p0, p1, p2, p3;
       int segment_number = 1;
       if (segment_number == 1)
       {
           t = 1;
           p0 = gApp->scene->playBackPosition[0];
           p1 = gApp->scene->playBackPosition[0];
           p2 = gApp->scene->playBackPosition[1];
           p3 = gApp->scene->playBackPosition[2];
           pos1 = getCatmullRomSpline(t, p0, p1, p2, p3);
           segment_number = segment_number + 1;
       }
       if (segment_number == 2)
       {
           t = 2;
           p0 = gApp->scene->playBackPosition[0];
           p1 = gApp->scene->playBackPosition[1];
           p2 = gApp->scene->playBackPosition[2];
           p3 = gApp->scene->playBackPosition[3];
           pos2 = getCatmullRomSpline(t, p0, p1, p2, p3);
           //gApp->scene->playback(pos2);
           segment_number = segment_number + 1;
       }
       if (segment_number == 3)
       {
           t = 3;
           p0 = gApp->scene->playBackPosition[1];
           p1 = gApp->scene->playBackPosition[2];
           p2 = gApp->scene->playBackPosition[3];
           p3 = gApp->scene->playBackPosition[4];
           pos3 = getCatmullRomSpline(t, p0, p1, p2, p3);
           //gApp->scene->playback(pos3);
           segment_number = segment_number + 1;
       }
       if (segment_number == 4)
       {
           t = 4;
           p0 = gApp->scene->playBackPosition[2];
           p1 = gApp->scene->playBackPosition[3];
           p2 = gApp->scene->playBackPosition[4];
           p3 = gApp->scene->playBackPosition[4];
           pos4 = getCatmullRomSpline(t, p0, p1, p2, p3);
           //gApp->scene->playback(pos4);
           segment_number = segment_number + 1;
       }
}

Vec3f Input::getCatmullRomSpline(float t, Vec3f p0, Vec3f p1, Vec3f p2, Vec3f p3)
{
    Vec3f a, b, c, d;
    a.x = 2 * p1.x;
    b.x = -p0.x + p2.x;
    c.x = 2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x;
    d.x = -p0.x + 3 * p1.x - 3 * p2.x + p3.x;
    a.y = 2 * p1.y;
    b.y = -p0.y + p2.y;
    c.y = 2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y;
    d.y = -p0.y + 3 * p1.y - 3 * p2.y + p3.y;
    a.z = 2 * p1.z;
    b.z = -p0.z + p2.z;
    c.z = 2 * p0.z - 5 * p1.z + 4 * p2.z - p3.z;
    d.z = -p0.z + 3 * p1.z - 3 * p2.z + p3.z;
    Vec3f pos = a * t * t * t + b * t * t + c * t + d;
    return pos;
}








// draw a simple terrain height field

#include "Render.hpp"
#include "GLapp.hpp"
#include "ImagePPM.hpp"
#include "Vec.inl"
#include "Scene.hpp"
// using core modern OpenGL
#include <GL/glew.h>
#include <GLFW/glfw3.h>

//
// load the terrain data
//
Terrain::Terrain(const char *elevationPPM, const char *texturePPM, const char *normalPPM)
{
    // load terrain heights
    ImagePPM elevation(elevationPPM);
    unsigned int w = elevation.width, h = elevation.height;
    gridSize = vec3<float>(float(w), float(h), 255.f);

    // world dimensions
    mapSize = vec3<float>(512, 512, 50);

    // build vertex, normal and texture coordinate arrays
    // * x & y are the position in the terrain grid
    for(unsigned int y=0;  y <= h;  ++y) {
        for(unsigned int x=0;  x <= w;  ++x) {
            // 3d vertex location: x,y from grid location, z from terrain data
            Vec3f P = (vec3<float>(float(x), float(y), elevation(x%w, y%h).r) / gridSize - 0.5f) * mapSize;
            vert.push_back(P);

            // compute normal & tangents from partial derivatives:
            //   position =
            //     (u / gridSize.x - .5) * mapSize.x
            //     (v / gridSize.y - .5) * mapSize.y
            //     (elevation / gridSize.z - .5) * mapSize.z
            //   the u-tangent is the per-component partial derivative by u:
            //      mapSize.x / gridSize.x
            //      0
            //      d(elevation(u,v))/du * mapSize.z / gridSize.z
            //   the v-tangent is the partial derivative by v
            //      0
            //      mapSize.y / gridSize.y
            //      d(elevation(u,v))/du * mapSize.z / gridSize.z
            //   the normal is the cross product of these

            // first approximate du = d(elevation(u,v))/du (and dv)
            // be careful to wrap indices to 0 <= x < w and 0 <= y < h
            float du = (elevation((x+1)%w, y%h).r - elevation((x+w-1)%w, y%h).r) * 0.5f * mapSize.z / gridSize.z;
            float dv = (elevation(x%w, (y+1)%h).r - elevation(x%w, (y+h-1)%h).r) * 0.5f * mapSize.z / gridSize.z;

            // final tangents and normal using these
            Vec3f T = normalize(vec3<float>(mapSize.x/gridSize.x, 0, du));
            Vec3f B = normalize(vec3<float>(0, mapSize.y/gridSize.y, dv));
            Vec3f N = normalize(T ^ B);
            tan.push_back(T);
            bitan.push_back(B);
            norm.push_back(N);
            // 2D texture coordinate for rocks texture, from grid location
            uv.push_back(vec2<float>(float(x),float(y)) / gridSize.xy);
        }
    }

    // build index array linking sets of three vertices into triangles
    // two triangles per square in the grid. Each vertex index is
    // essentially its unfolded grid array position. Be careful that
    // each triangle ends up in counter-clockwise order
    for(unsigned int y=0; y<h; ++y) {
        for(unsigned int x=0; x<w; ++x) {
            indices.push_back((w+1)* y    + x);
            indices.push_back((w+1)* y    + x+1);
            indices.push_back((w+1)*(y+1) + x+1);

            indices.push_back((w+1)* y    + x);
            indices.push_back((w+1)*(y+1) + x+1);
            indices.push_back((w+1)*(y+1) + x);
        }
    }

    init("terrain.vert", "terrain.frag", texturePPM, normalPPM);
}

// update elevation of viewer position, return false if not over a triangle
bool Terrain::elevation(Vec3f &p)
{
    // loop over triangles to check
    for(int i=0; i < indices.size(); i += 3) {
        Vec3f v0 = vert[indices[i]];
        Vec3f v1 = vert[indices[i+1]];
        Vec3f v2 = vert[indices[i+2]];

        // barycentric coordinate with z values all set to 0:
        //   v=(v2-v1)^(p-v1); n = (v2-v1)^(v0-v1)
        //   a = dot(n,v) / dot(n,n)
        // since z's are all 0, only z component of cross product is non-zero
        // allows algebraic simplification to this: 0 1 2 0 1
        float n = v0.x*v1.y - v1.x*v0.y + v1.x*v2.y - v2.x*v1.y + v2.x*v0.y - v0.x*v2.y;
        float a = (p.x*v1.y - v1.x*p.y + v1.x*v2.y - v2.x*v1.y + v2.x*p.y - p.x*v2.y)/n;
        float b = (v0.x*p.y - p.x*v0.y + p.x*v2.y - v2.x*p.y + v2.x*v0.y - v0.x*v2.y)/n;
        float c = (v0.x*v1.y - v1.x*v0.y + v1.x*p.y - p.x*v1.y + p.x*v0.y - v0.x*p.y)/n;

        // found the triangle
        if (a >= 0 && b >= 0 && c >= 0) {
            p.z = a * v0.z + b * v1.z + c * v2.z;
            return true;
        }
    }

    // no match, outside terrain
    return false;
}

void Terrain::init(const char* vertexshader, const char* fragmentshader, const char* texture, const char* normals)
{
    // buffer objects to be used later
    glGenTextures(NUM_TEXTURES, textureIDs);
    glGenBuffers(NUM_BUFFERS, bufferIDs);
    glGenVertexArrays(1, &varrayID);

    // load color image into a named texture
    ImagePPM(texture).loadTexture(textureIDs[COLOR_TEXTURE]);
    //load another texture normal mapping
    ImagePPM(normals).loadTexture(textureIDs[NUM_NORMALS]);
    //ImagePPM(texture).loadTexture(textureIDs[NUM_NORMALS]);

    // load vertex and index array to GPU
    glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[POSITION_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, vert.size() * sizeof(vert[0]), &vert[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[NORMAL_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, norm.size() * sizeof(norm[0]), &norm[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[UV_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, uv.size() * sizeof(uv[0]), &uv[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferIDs[INDEX_BUFFER]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(indices[0]), &indices[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferIDs[TANGENT_BUFFER]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, tan.size() * sizeof(tan[0]), &tan[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferIDs[BITANGENT_BUFFER]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, bitan.size() * sizeof(bitan[0]), &bitan[0], GL_STATIC_DRAW);

    // initial shader load
    shaderParts[0].id = glCreateShader(GL_VERTEX_SHADER);
    shaderParts[0].file = vertexshader;
    shaderParts[1].id = glCreateShader(GL_FRAGMENT_SHADER);
    shaderParts[1].file = fragmentshader;
    shaderID = glCreateProgram();
    updateShaders();
}

Render::~Render()
{
    glDeleteShader(shaderParts[0].id);
    glDeleteShader(shaderParts[1].id);
    glDeleteProgram(shaderID);
    glDeleteTextures(NUM_TEXTURES, textureIDs);
    glDeleteBuffers(NUM_BUFFERS, bufferIDs);
    glDeleteVertexArrays(1, &varrayID);
}

//
// load (or replace) terrain shaders
//
void Terrain::updateShaders()
{
    loadShaders(shaderID, sizeof(shaderParts)/sizeof(*shaderParts), 
            shaderParts);
    glUseProgram(shaderID);

    // (re)connect view and projection matrices
    glUniformBlockBinding(shaderID, 
            glGetUniformBlockIndex(shaderID,"SceneData"),
            GLapp::SCENE_UNIFORMS);

     //map shader name for texture to GL_TEXTURE0 used in draw
    glUniform1i(glGetUniformLocation(shaderID, "colorTexture"), 0);
    // normal shader name for texture to GL_TEXTURE1 used in draw
    glUniform1i(glGetUniformLocation(shaderID, "normalTexture"), 1);
     //re-connect attribute arrays
    glBindVertexArray(varrayID);

    GLint positionAttrib = glGetAttribLocation(shaderID, "vPosition");
    glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[POSITION_BUFFER]);
    glVertexAttribPointer(positionAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(positionAttrib);

    GLint normalAttrib = glGetAttribLocation(shaderID, "vNormal");
    glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[NORMAL_BUFFER]);
    glVertexAttribPointer(normalAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(normalAttrib);

    GLint uvAttrib = glGetAttribLocation(shaderID, "vUV");
    glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[UV_BUFFER]);
    glVertexAttribPointer(uvAttrib, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(uvAttrib);

   GLint tangentAttrib = glGetAttribLocation(shaderID, "vTangent");
   glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[TANGENT_BUFFER]);
   glVertexAttribPointer(tangentAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
   glEnableVertexAttribArray(tangentAttrib);

   GLint bitangentAttrib = glGetAttribLocation(shaderID, "vBitangent");
   glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[BITANGENT_BUFFER]);
   glVertexAttribPointer(bitangentAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
   glEnableVertexAttribArray(bitangentAttrib);
    
}

//
// this is called every time the terrain needs to be redrawn 
//
void Render::draw() const
{
    // enable shaders
    glUseProgram(shaderID);

    // enable vertex arrays
    glBindVertexArray(varrayID);

    // bind color texture to active texture 0
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureIDs[COLOR_TEXTURE]);
    
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, textureIDs[NUM_NORMALS]);
    
    //glBindTexture(GL_TEXTURE_2D, bufferIDs[POSITION_BUFFER]);

    // draw the triangles for each three indices
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferIDs[INDEX_BUFFER]);
    glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
}



Neehar Thakkar
PY95819

-> I have completed the conversion to p0, p1, p2 and p3 position to create an
array of positions at last 5 seconds.
-> Calculated p(t) for all the four segments between the start and the end positions.
-> I have converted Matrix to Quaternions and used that to change the rotation matrix.
-> I couldnt figure how to do the rest part.


References:

->https://stackoverflow.com/questions/30562692/rotation-matrix-to-quaternion-and-back-what-is-wrong
->https://medium.com/@csaba.apagyi/finding-catmull-rom-spline-and-line-intersection-part-2-mathematical-approach-dfb969019746

// terrain data and drawing
#pragma once

#include "Vec.hpp"
#include "Shader.hpp"
#include <vector>
#include <map>
#include <string>

struct GLFWwindow;

class Render {
public:
    // arrays defining triangles for GPU
    std::vector<Vec3f> vert;    // per-vertex position
    std::vector<Vec3f> norm;    // per-vertex normal
    std::vector<Vec2f> uv;      // per-vertex texture coordinate
    std::vector<unsigned int> indices;  // 3 vertex indices per triangle
public:
    unsigned int varrayID;
    // GL texture IDs
    enum { COLOR_TEXTURE, NUM_NORMALS, NUM_TEXTURES};
    unsigned int textureIDs[NUM_TEXTURES]; 

    // GL buffer object IDs
    enum { POSITION_BUFFER, NORMAL_BUFFER, UV_BUFFER, TANGENT_BUFFER, BITANGENT_BUFFER, INDEX_BUFFER, NUM_BUFFERS };
    unsigned int bufferIDs[NUM_BUFFERS];

    // GL shaders
    unsigned int shaderID;      // ID for shader program
    ShaderInfo shaderParts[2];  // vertex & fragment shader info

public:
    Render() {};   //defaault constructor

    void init(const char* vertexshader, const char* fragmentshader, const char* texture, const char* normals) {};
    
    //clean up allocated memory
    ~Render();

    // load/reload shaders
    void updateShaders() {};

    // draw this terrain object
    void draw() const;

};
// terrain data and rendering methods
class Terrain : public Render {
// private data
private:
    Vec3f gridSize;             // elevation grid size
    Vec3f mapSize;          //size of the terrain
// public methods
public:
    std::vector<Vec3f> tan;     //per-vertex tangent
    std::vector<Vec3f> bitan;   //per-vertex bitangent
public:
    virtual void init(const char* vertexshader, const char* fragmentshader, const char* texture, const char* normals);
    // load terrain, given elevation image and surface texture
    // load/reload shaders
    virtual void updateShaders();
    Terrain(const char *elevationPPM, const char *texturePPM, const char *normalPPM);
    // update elevation of viewer position, return false if not over a triangle
    bool elevation(Vec3f &position);

};

class character : public Render {
public:
    std::string line;
    unsigned int count = 0;
private:   
    std::map<std::string, int> mapping;
    std::vector<Vec3f> temp_vertices;
    std::vector<Vec2f> temp_uvs;
    std::vector<Vec3f> temp_normals;
public:
    virtual void init(const char* vertexshader, const char* fragmentshader, const char* texture, const char* normals);
    // load/reload shaders
    virtual void updateShaders();
    character(const char* texturePPM, const char* characterobj, const char* normalPPM);
};
// data shared across entire scene
// expected to change up to once per frame
#pragma once

#include "Xform.hpp"
#include "Vec.hpp"

struct GLFWwindow;

class Scene {
private:
    // GL uniform buffer IDs
    enum {MATRIX_BUFFER, NUM_BUFFERS};
    unsigned int bufferIDs[NUM_BUFFERS];

public:
    struct ShaderData {
        Xform4f viewmat, projection; // viewing matrices           
        Vec4f normal_map;              // normal_map.rgb = color, normal_map.a = normal_map enabled
        Vec4f surface_gradient;         //Surface Gradient.rgb = color, surface_gradient.a = surface gradient enabled
        Vec4f fog;                   // fog.rgb = color, fog.a = fog enabled
    } sdata;

    int width, height;         // current window dimensions
    float pan, tilt;           // horizontal and vertical Euler angles
    Vec3f playBackPosition[5];  // play back position
    Vec4f Q0, Q1, Q2, Q3;                //Quaternions
    Vec3f position;            // character position
public:
    float t = 1;
    // create with initial window size and orbit location
    Scene(GLFWwindow *win);
    void Move(Vec3f newPosition);
    // set up new window viewport and projection
    void viewport(GLFWwindow *win);
    // set view using orbitAngle
    void view();
    // Object view 
    void object();
    // update shader uniform state each frame
    void update() const;
    // Rotation interpolation playback
    void playback(Vec3f newPosition);
    // Position
    Vec3f quater(Vec4f Q0);
};

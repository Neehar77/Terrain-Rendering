//
// Simple GL example
//


#include "GLapp.hpp"
#include "Input.hpp"
#include "Scene.hpp"
#include "Render.hpp"
#include "Vec.inl"

// using core modern OpenGL
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <stdio.h>
#include <assert.h>

// single global application context
GLapp *gApp = nullptr;

///////
// GLFW callbacks must use extern "C"
extern "C" {
    // called for GLFW error
    void winError(int error, const char *description)
    {
        fprintf(stderr, "GLFW error: %s\n", description);
    }

    // called whenever the window size changes
    void reshape(GLFWwindow *win, int width, int height)
    {
        gApp->scene->viewport(win);
    }

    // called when mouse button is pressed
    void mousePress(GLFWwindow *win, int button, int action, int mods)
    {
        gApp->input->mousePress(win, button, action);
    }

    // called when mouse is moved
    void mouseMove(GLFWwindow *win, double x, double y)
    {
        gApp->input->mouseMove(win, x,y);
    }

    // called on any keypress
    void keyPress(GLFWwindow *win, int key, int scancode, int action, int mods)
    {
        gApp->input->keyPress(win, key, action);
    }
}

// initialize GLFW - windows and interaction
GLapp::GLapp()
{
    // set error callback before init
    glfwSetErrorCallback(winError);
    int ok = glfwInit();
    assert(ok);

    // OpenGL version: YOU MAY NEED TO ADJUST VERSION OR OPTIONS!
    // When figuring out the settings that will work for you, make
    // sure you can see error messages on console output.
    //
    // My driver needs FORWARD_COMPAT, but others will need to comment that out.
    // Likely changes for other versions:
    //       OpenGL 4.0 (2010): change VERSION_MAJOR to 3, MINOR to 3
    //         Use "400 core" for the "#version" line in the .vert and .frag files
    //       OpenGL 3.3 (2010): change VERSION_MAJOR to 3, MINOR to 3
    //         Use "330 core" for the "#version" line in the .vert and .frag files
    //       OpenGL 3.2 (2009): change VERSION_MAJOR to 3, MINOR to 2
    //         Use "150 core" for the "#version" line in the .vert and .frag files
    //       OpenGL 3.1 (2009): change VERSION_MAJOR to 3, MINOR to 1
    //         comment out PROFILE line
    //         Use "140" for the "#version" line in the .vert and .frag files
    //       OpenGL 3.0 (2008): does not support features we need
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_DEBUG_CONTEXT, GL_TRUE);

    // ask for a window with dimensions 843 x 480 (HD 480p)
    win = glfwCreateWindow(843, 480, "Simple OpenGL Application", 0, 0);
    assert(win);

    glfwMakeContextCurrent(win);

    // GLEW handles OpenGL shared library access
    glewExperimental = true;
    glewInit();

    // set callback functions to be called by GLFW
    glfwSetFramebufferSizeCallback(win, reshape);
    glfwSetKeyCallback(win, keyPress);
    glfwSetMouseButtonCallback(win, mousePress);
    glfwSetCursorPosCallback(win, mouseMove);

    // set OpenGL state
    glEnable(GL_DEPTH_TEST);      // tell OpenGL to handle overlapping surfaces

    // initialize context (after GLFW)
    scene = new Scene(win);     // view and per-frame uniforms
    input = new Input;       // keyboard & mouse
    terrain = new Terrain("terrain.ppm", "pebbles.ppm", "pebbles-norm.ppm");
    Character = new character("olano.ppm", "olano.obj", "pebbles-norm.ppm");
    redraw = true;
}

///////
// Clean up any context data
GLapp::~GLapp()
{
    delete scene;
    delete input;
    delete terrain;
    glfwDestroyWindow(win);
    glfwTerminate();
}

int main(int argc, char *argv[])
{
    gApp = new GLapp();
    gApp->scene->Move(vec3<float>(0,0,0));
    //gApp->scene->objectView(vec3<float>(0, 0, 0));

    // loop until GLFW says it's time to quit
    while (!glfwWindowShouldClose(gApp->win)) {
        // check for continuous key updates to view
        gApp->input->keyUpdate();

        if (gApp->redraw) {
            // we're handing the redraw now
            gApp->redraw = false;

            // clear old screen contents
            glClearColor(
                gApp->scene->sdata.normal_map.r,
                gApp->scene->sdata.normal_map.g,
                gApp->scene->sdata.normal_map.b,
                1.f);
            glClearColor(
                    gApp->scene->sdata.fog.r,
                    gApp->scene->sdata.fog.g,
                    gApp->scene->sdata.fog.b,
                    1.f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            gApp->scene->view();
            // draw something
            gApp->scene->update();
            //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            gApp->terrain->draw();
            //gApp->scene->objectView(gApp->scene->position);
            //gApp->scene->sdata.viewmat;
            gApp->scene->object();
            gApp->scene->update();
            gApp->Character->draw();

            //glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

            

            // show what we drew
            glfwSwapBuffers(gApp->win);
        }

        // wait for user input
        glfwPollEvents();
    }

    delete gApp;
    return 0;
}

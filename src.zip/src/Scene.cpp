// data shared across entire scene
// expected to change up to once per frame
// primarily view information

#include "Scene.hpp"
#include "Render.hpp"
#include "Xform.inl"
#include "GLapp.hpp"
#include "Input.hpp"

// using core modern OpenGL
#include <GL/glew.h>
#include <GLFW/glfw3.h>

// for offsetof
#include <cstddef>

#ifndef F_PI
#define F_PI 3.1415926f
#endif

//
// create and initialize view
//
Scene::Scene(GLFWwindow *win) 
    : pan(0), tilt(-1.4f)
{
    // create uniform buffer objects
    glGenBuffers(NUM_BUFFERS, bufferIDs);
    glBindBuffer(GL_UNIFORM_BUFFER, bufferIDs[MATRIX_BUFFER]);
    glBufferData(GL_UNIFORM_BUFFER, sizeof(ShaderData), 0, GL_STREAM_DRAW);
    glBindBufferBase(GL_UNIFORM_BUFFER, GLapp::SCENE_UNIFORMS,
            bufferIDs[MATRIX_BUFFER]);

    // initialize scene data
    position = vec3<float>(0,0,0);
    sdata.normal_map = vec4<float>(1, 1, 1, 0);  //Normal Mapping off
    sdata.surface_gradient = vec4<float>(1, 1, 1, 0); //Surface Gradient off
    sdata.fog = vec4<float>(1,1,1,0); // white fog, off
    Move(position);
    viewport(win); 
    //view();
    //objectView(position);
}
//
// New view, pointing to origin, at specified angle
//
void Scene::Move(Vec3f newPosition)
{
    // update position based on terrain
    if (gApp && gApp->terrain->elevation(newPosition)) {
        position = newPosition;
        position.z += 50;
    }
}
void Scene::view()
{
    sdata.viewmat = translate4fp(vec3<float>(0.f, 0.f, -110)) * xrotate4fp(tilt)
        * zrotate4fp(pan) * translate4fp(-position);
}
void Scene::playback(Vec3f newPosition)
{
    sdata.viewmat = translate4fp(newPosition);
    Xform4f m =  sdata.viewmat;
    float t = sdata.viewmat.matrix[0][0] + sdata.viewmat.matrix[1][1] + sdata.viewmat.matrix[2][2];
    if (t >= 0) { // by w
        float s = sqrt(t + 1);
        Q0.w = 0.5 * s;
        s = 0.5 / s;
        Q0.x = (m.matrix[2][1] - m.matrix[1][2]) * s;
        Q0.y = (m.matrix[0][2] - m.matrix[2][0]) * s;
        Q0.z = (m.matrix[1][0] - m.matrix[0][1]) * s;
        Vec3f qe0 = quater(Q0);
    }
    else if ((m.matrix[0][0] > m.matrix[1][1]) && (m.matrix[0][0] > m.matrix[2][2])) { // by x
        float s = sqrt(1 + m.matrix[0][0] - m.matrix[1][1] - m.matrix[2][2]);
        Q1.x = s * 0.5;
        s = 0.5 / s;
        Q1.y = (m.matrix[1][0] + m.matrix[0][1]) * s;
        Q1.z = (m.matrix[0][2] + m.matrix[2][0]) * s;
        Q1.w = (m.matrix[2][1] - m.matrix[1][2]) * s;
        Vec3f qe1 = quater(Q1);
    }
    else if (m.matrix[1][1] > m.matrix[2][2]) { // by y
        float s = sqrt(1 + m.matrix[1][1] - m.matrix[0][0] - m.matrix[2][2]);
        Q2.y = s * 0.5;
        s = 0.5 / s;
        Q2.x = (m.matrix[1][0] + m.matrix[0][1]) * s;
        Q2.z = (m.matrix[2][1] + m.matrix[1][2]) * s;
        Q2.w = (m.matrix[0][2] - m.matrix[2][0]) * s;
        Vec3f qe2 = quater(Q2);
    }
    else { // by z
        float s = sqrt(1 + m.matrix[2][2] - m.matrix[0][0] - m.matrix[1][1]);
        Q3.z = s * 0.5;
        s = 0.5 / s;
        Q3.x = (m.matrix[0][2] + m.matrix[2][0]) * s;
        Q3.y = (m.matrix[2][1] + m.matrix[1][2]) * s;
        Q3.w = (m.matrix[1][0] - m.matrix[0][1]) * s;
        Vec3f qe3 = quater(Q3);
    }
}

Vec3f Scene::quater(Vec4f Q)
{
    Vec3f a, b, c, d;
    a.x = 2 * Q.y;
    b.x = -Q.x + Q.z;
    c.x = 2 * Q.x - 5 * Q.y + 4 * Q.z - Q3.w;
    d.x = -Q.x + 3 * Q.y - 3 * Q.z + Q.w;
    a.y = 2 * Q.y;
    b.y = -Q.x + Q.z;
    c.y = 2 * Q.x - 5 * Q.y + 4 * Q.z - Q.w;
    d.y = -Q.x + 3 * Q.y - 3 * Q.z + Q.w;
    a.z = 2 * Q.y;
    b.z = -Q.x + Q.z;
    c.z = 2 * Q.x - 5 * Q.y + 4 * Q.z - Q.w;
    d.z = -Q.x + 3 * Q.y - 3 * Q.z + Q3.w;
    Vec3f pos = a * t * t * t + b * t * t + c * t + d;
    t = t + 1;
    return Vec3f();
}

void Scene::object()
{
    sdata.viewmat = sdata.viewmat * translate4fp(position - vec3<float>(0.f, 0.f, 50)) *
        zrotate4fp(F_PI / 2 - pan) * xrotate4fp(F_PI / 2) * scale4fp(vec3<float>(50, 50, 50));
}
// This is called when window is created or resized
// Adjust projection accordingly.
//
void Scene::viewport(GLFWwindow *win)
{
    // get window dimensions
    glfwGetFramebufferSize(win, &width, &height);

    // this viewport makes a 1 to 1 mapping of physical pixels to GL
    // "logical" pixels
    glViewport(0, 0, width, height);

    // adjust 3D projection into this window
    sdata.projection = perspective4fp(F_PI/4, (float)width/height, 1, 10000);

    if (gApp) gApp->redraw = true;
}
//
// call before drawing each frame to update per-frame scene state
//
void Scene::update() const
{
    // update uniform block
    glBindBuffer(GL_UNIFORM_BUFFER, bufferIDs[MATRIX_BUFFER]);
    glBufferSubData(GL_UNIFORM_BUFFER, 0, sizeof(ShaderData), &sdata);
}



